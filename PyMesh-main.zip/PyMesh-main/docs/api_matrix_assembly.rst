Finite Element Matrix Assembly
==============================

In digital geometry processing, one often have to assemble matrices that
corresponding to discrete differential operators.  PyMesh provides a simple
interface to assemble commonly used matrices.

.. autoclass:: pymesh.Assembler
    :members:

